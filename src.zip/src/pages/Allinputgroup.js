import { Col , Row } from "react-bootstrap";
import "../css/Allinputgroup.css";
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import { BsSearch } from "react-icons/bs";
import { CiLocationOn } from "react-icons/ci";


function Allinputgroup(){
    return(
        <Row >
            <Col xxl={4} xl={4} lg={4} md={12} sm={12} xs={12} >
                <div className="search_input">
                    <span><BsSearch/></span>
            
                    <Form.Control type="text" placeholder="What position are you looking for?"/>    
                </div>
            </Col>
            <Col xxl={4} xl={4} lg={4} md={10} sm={10} xs={10} >
                <div className="search_input">
                    <span><CiLocationOn/></span>
                    <Form.Control type="text" placeholder="Loaction"/>    
                </div>
            </Col>
            <Col xxl={2} xl={2} lg={2} md={2} sm={2} xs={2} >
                <div >

                    <span className="search_item"><BsSearch/></span>
                </div>
            </Col>
        </Row>
    )
}
export default Allinputgroup;